//
//  Plant+CoreDataClass.swift
//  plantMonitor
//
//  Created by Yeabsera Damte on 11/22/24.
//
//

import Foundation
import CoreData

@objc(Plant)
public class Plant: NSManagedObject {

}
